package com.deliveryassistant.callforwarder

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        const val PREFS_NAME = "call_forwarder_prefs"
        const val KEY_IP = "pc_ip"
        const val KEY_PORT = "pc_port"
        const val DEFAULT_PORT = "4545"

        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG
        )
    }

    private lateinit var ipInput: EditText
    private lateinit var portInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ipInput = findViewById(R.id.ipInput)
        portInput = findViewById(R.id.portInput)
        statusText = findViewById(R.id.statusText)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val permissionButton = findViewById<Button>(R.id.permissionButton)

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        ipInput.setText(prefs.getString(KEY_IP, ""))
        portInput.setText(prefs.getString(KEY_PORT, DEFAULT_PORT))

        saveButton.setOnClickListener {
            val ip = ipInput.text.toString().trim()
            val port = portInput.text.toString().trim().ifEmpty { DEFAULT_PORT }
            if (ip.isEmpty()) {
                Toast.makeText(this, "دخّل عنوان IP الخاص بالحاسوب", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString(KEY_IP, ip).putString(KEY_PORT, port).apply()
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
            updateStatus()
        }

        permissionButton.setOnClickListener { requestPermissionsIfNeeded() }

        requestPermissionsIfNeeded()
        updateStatus()
    }

    private fun requestPermissionsIfNeeded() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
        updateStatus()
    }

    private fun updateStatus() {
        val granted = REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        statusText.text = if (granted)
            "الحالة: الصلاحيات مفعّلة ✅ — التطبيق جاهز لمراقبة المكالمات"
        else
            "الحالة: الصلاحيات غير مفعّلة ❌ — اضغط زر تفعيل الصلاحيات"
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }
}
