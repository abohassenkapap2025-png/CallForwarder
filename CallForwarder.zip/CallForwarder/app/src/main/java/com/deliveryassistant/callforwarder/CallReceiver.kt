package com.deliveryassistant.callforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.intent.action.PHONE_STATE") return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        // نهتم فقط بلحظة الرنين (RINGING) لأنها اللحظة اللي فيها رقم المتصل متوفر
        if (state == TelephonyManager.EXTRA_STATE_RINGING && !number.isNullOrBlank()) {
            val prefs = context.getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val ip = prefs.getString(MainActivity.KEY_IP, null)
            val port = prefs.getString(MainActivity.KEY_PORT, MainActivity.DEFAULT_PORT)

            if (!ip.isNullOrBlank()) {
                NetworkSender.sendIncomingCall(ip, port ?: MainActivity.DEFAULT_PORT, number)
            }
        }
    }
}
