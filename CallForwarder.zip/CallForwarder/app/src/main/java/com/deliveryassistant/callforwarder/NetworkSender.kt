package com.deliveryassistant.callforwarder

import android.util.Log
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

object NetworkSender {

    private val client = OkHttpClient()
    private const val TAG = "CallForwarder"

    fun sendIncomingCall(ip: String, port: String, phoneNumber: String) {
        val json = JSONObject().apply {
            put("phone", phoneNumber)
            put("timestamp", System.currentTimeMillis())
        }

        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("http://$ip:$port/incoming-call")
            .post(body)
            .build()

        // إرسال بالخلفية، ما يوقف التطبيق ولا يهم لو فشل (مثلاً الحاسوب مطفي)
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.w(TAG, "فشل إرسال رقم المتصل: ${e.message}")
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                Log.i(TAG, "تم إرسال الرقم بنجاح: $phoneNumber")
                response.close()
            }
        })
    }
}
