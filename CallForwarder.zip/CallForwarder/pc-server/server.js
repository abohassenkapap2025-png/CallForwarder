// سيرفر تجريبي بسيط للتأكد إن تطبيق الأندرويد يرسل رقم المتصل بنجاح.
// شغله بأمر: node server.js
// بعدين خلي تطبيق الأندرويد يرسل لعنوان IP جهازك على المنفذ 4545.

const http = require("http");

const PORT = 4545;

const server = http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/incoming-call") {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      try {
        const data = JSON.parse(body);
        const time = new Date().toLocaleTimeString("ar-IQ");
        console.log(`📞 [${time}] رقم متصل جديد: ${data.phone}`);
      } catch (e) {
        console.log("⚠️ خطأ بقراءة البيانات:", e.message);
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: true }));
    });
  } else {
    res.writeHead(404);
    res.end();
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ السيرفر التجريبي شغال على المنفذ ${PORT}`);
  console.log(`تأكد إن الهاتف والحاسوب على نفس شبكة الواي فاي.`);
  console.log(`ادخل عنوان IP هذا الجهاز بتطبيق الأندرويد.`);
});
